export const config = {
  contactEmail: 'contacto@ebtmedia.cl',
};